/*Open https://cpwst.agiletestingalliance.org/
-	Scroll to the Twitter Section
-	Find the no of tweets till “Load more tweets” button and print on the console. Refer below Screenshot 
-	Print entire message of the first Tweet on the console . Refer Below Screenshot 
For Ex : Get ready for a very Interesting Webinar #today (22nd April) at 7 pm (IST) on #topic "Improving quality efficiency & efficacy with #XSCALE" by Masa K. Maeda, Ph.D. If you have missed you can register now
-	Hover to the tooltip and Take screenshot ( i.e. hover onto @AgileTAlliance )
-	Open on the above link which opens  a Twitter window. 
-  Verify that the last tweet in the tweet section is present on the twitter page  .*/

package cpsatExamJunit;

import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import com.testing.base.TestBase;

public class Set13_Question3 extends TestBase{

	//Opening the browser
	@Before
	public void launchBrowser() {
		init("Chrome","https://cpwst.agiletestingalliance.org/");
	}
	
	@Test
	public void validateApplication() throws InterruptedException {
		checkPageReady();
		
		//Scroll to the Twitter Section
		scrollIntoView(d.findElement(By.xpath("//div[@class='social_container']/h3")));
		
		//Find the no of tweets till “Load more tweets” button and print on the console. 
		d.switchTo().frame("twitter-widget-0");
		List<WebElement> tweets = d.findElements(By.xpath("//div[@class='TweetAuthor-nameScreenNameContainer']/span/span"));
		System.out.println(tweets.size());
		for(int i=0;i<tweets.size();i++) {
			WebElement tweet = tweets.get(i);
			System.out.println(tweet.getText());
		}
		
		//Print entire message of the first Tweet on the console
		WebElement message = d.findElement(By.xpath("//div[@data-tweet-id='1257590596144939008']/p"));
		System.out.println(message.getText());
		
		wait(5);
		
		//Hover to the tooltip and Take screenshot
		Actions action = new Actions(d);
		action.moveToElement(waitForElementToVisible(d.findElement(By.xpath("//span[@class='timeline-Header-byline']/a")))).build().perform();
		takeTheScreenShot("Set13_Question3.jpg");
		
		//Open on the above link which opens  a Twitter window
		d.findElement(By.xpath("//span[@class='timeline-Header-byline']/a")).click();
		wait(10);

		for (String winHandle:d.getWindowHandles()) {
			d.switchTo().window(winHandle);
		}
		WebElement message1 = d.findElement(By.xpath("//div[@class='css-901oao r-hkyrab r-1qd0xha r-a023e6 r-16dba41 r-ad9z0x r-bcqeeo r-bnwqim r-qvutc0']"));
		String mess1 = message1.getText();
		System.out.println(message1.getText());
		
		wait(5);
		//Verify that the last tweet in the tweet section present on the twitter page
		if(mess1.contains("We would like to Welcome Vidhi Saxena of Nagarro")){
			System.out.println("Tweets are present in both places");
		}
		else {
			System.out.println("Not Present");
		}
		
	}	
	@After
	public void closeBrowser() {
		d.quit();
	}
}
