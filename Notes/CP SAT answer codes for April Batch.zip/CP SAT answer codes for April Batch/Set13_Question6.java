/* Create a Junit Runner for all the Junit classes*/

package cpsatExamJunit;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)
@Suite.SuiteClasses({cpsatExamJunit.Set13_Question1.class,cpsatExamJunit.Set13_Question2.class,cpsatExamJunit.Set13_Question3.class})
public class Set13_Question6 {

}
