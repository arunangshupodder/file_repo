/*
a. Open the following https://gitlab.com/users/sign_up website
b. Click on the register button without filling in any data and take a screenshot. It will be showing something like the below. Take a screen shot(Refer Fig 4.1). (1 mark)
c. Please look at the below two images (Refer Fig 4.2)
    1. Enter a valid email address and check if the error message is gone ( 1 marks) 
    2. Enter an invalid email address and check if the error message is there. (2 marks)
    3. Confirm if the border of the field is RED (2 marks)
    4. Enter a password which is more than 8 characters and see if the error message goes (1 mark)
    5. Enter a password which is less than 8 characters and see if the error message “Minimum length is 8 characters.” Is back (1 mark)
    6. Check the if the border of the field is Red (1 mark)
d. Without clicking on I accept the term and policy – click on the register button – you will get a transient alert (“Please check this box if you want to proceed”) – take a screenshot with the alert visible.
(Refer Fig 4.3). (3 marks)
e. Fill all the fields and do not click on the checkbox next to “I m not a robot” and click on register. It would throw an error page like below . (3 marks)
Confirm if the field values entered before are the same as before except the password and I accept check boxes and the error message shown is There was an error with the reCAPTCHA. Please solve the reCAPTCHA again (Refer Fig 4.4)
*/	
package cpsatExamTestNG;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import com.testing.base.TestBase;

public class Set11_Question4 extends TestBase {
@BeforeMethod
//launching the browser
public void launchBrowser()
{
	init("Chrome","https://gitlab.com/users/sign_up");
}

@Test
public void validateApplication() throws InterruptedException {
	//to check page readiness
	checkPageReady();
	//click on register button and take screenshot
	d.findElement(By.xpath("//input[@type='submit']")).click();
	takeTheScreenShot("Question11_4_1.jpg");
	//Enter a valid email address and check if the error message is gone
	WebElement p = d.findElement(By.xpath("//p[contains(text(),'Please provide a valid email address.')]"));
	WebElement email = d.findElement(By.xpath("//input[@type='email']"));
	wait(2);
	email.click();
	email.sendKeys("abc@gmail.com");
	if(p.getText().contains("Please provide a valid email address.")) {
	System.out.println("Not a valid email address");
	}
	else {
		System.out.println("Valid email address");
	}
	//Enter an invalid email address and check if the error message is there
	wait(2);
	email.clear();
	email.sendKeys("abc.gmail.com");
	if(p.getText().contains("Please provide a valid email address.")) {
		System.out.println("Not a valid email address");
	}
	else {
		System.out.println("Valid email address");
	}
	//Confirm if the border of the field is RED 
	email.clear();
	wait(2);
	String border = email.getCssValue("border-bottom-color");
	System.out.println(border);	
	Assert.assertEquals("rgba(219, 59, 33, 1)", border);
	//Enter a password which is more than 8 characters and see if the error message goes
	WebElement pass = d.findElement(By.xpath("//p[contains(text(),'Minimum length is 8 characters.')]"));
	WebElement password = d.findElement(By.id("new_user_password"));
	wait(2);
	password.click();
	password.sendKeys("abcdefgh");
	if(pass.getText().contains("Minimum length is 8 characters.")) {
		System.out.println("Password not valid");
		}
		else {
			System.out.println("Valid password");
		}
		//Enter a password which is less than 8 characters and see if the error message “Minimum length is 8 characters.” Is back
		wait(2);
		password.clear();
		password.sendKeys("abcdefg");
		if(pass.getText().contains("Minimum length is 8 characters.")) {
			System.out.println("Password not valid");
			}
			else {
				System.out.println("Valid password");
			}
		//Confirm if the border of the field is RED 
		password.clear();
		wait(2);
		String border1 = password.getCssValue("border-bottom-color");
		System.out.println(border1);	
		Assert.assertEquals("rgba(219, 59, 33, 1)", border1);
		//Without clicking on I accept the term and policy – click on the register button – you will get a transient alert (“Please check this box if you want to proceed”) – Assert if the alert comes or not and also take a screenshot with the alert visible.
		d.findElement(By.id("new_user_first_name")).sendKeys("a");
		d.findElement(By.id("new_user_last_name")).sendKeys("b");
		d.findElement(By.id("new_user_username")).sendKeys("adhwst");
		d.findElement(By.id("new_user_email")).sendKeys("abc@gmail.com");
		d.findElement(By.id("new_user_password")).sendKeys("abcdefgh");
		d.findElement(By.id("new_user_email_opted_in")).click();
		d.findElement(By.xpath("//input[@type='submit']")).click();
		wait(1);
		takeTheScreenShot("Question11_4_2.jpg");
		//Fill all the fields and do not click on the checkbox next to “I m not a robot” and click on register. It would throw an error page
		d.findElement(By.id("terms_opt_in")).click();
		d.findElement(By.xpath("//input[@type='submit']")).click();
		String errorMessage = d.findElement(By.xpath("//div[@class='flash-alert mb-2']/span")).getText();
		Assert.assertEquals(errorMessage, "There was an error with the reCAPTCHA. Please solve the reCAPTCHA again.");
		//Confirm if the field values entered before are the same as before except the password and I accept check boxes and the error message shown is There was an error with the reCAPTCHA. Please solve the reCAPTCHA again
		Assert.assertEquals("a", d.findElement(By.id("new_user_first_name")).getAttribute("value"));
		Assert.assertEquals("b", d.findElement(By.id("new_user_last_name")).getAttribute("value"));
		Assert.assertEquals("adhwst", d.findElement(By.id("new_user_username")).getAttribute("value"));
		Assert.assertEquals("abc@gmail.com", d.findElement(By.id("new_user_email")).getAttribute("value"));
		Assert.assertEquals("", d.findElement(By.id("new_user_password")).getAttribute("value"));
		if(d.findElement(By.id("new_user_email_opted_in")).isSelected()) {
			Assert.assertTrue(true);
		}
		if(d.findElement(By.id("terms_opt_in")).isSelected()) {
			Assert.assertTrue(false);
		}
		else {
			Assert.assertTrue(true);
		}
}
@AfterMethod
public void closeBrowser() {
	d.close();
}
}
