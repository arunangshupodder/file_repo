package cpsatExamJunit;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;

@RunWith(Suite.class)
@Suite.SuiteClasses({cpsatExamJunit.Set11_Question3.class,cpsatExamJunit.Set11_Question2.class})
public class Set11_Question6 {
}
