/*Create a Page Object Model class Question3FooterPom.java for the following 
	a - https://gitlab.com/
	b – For the following Menu locators at the bottom of the page(Refer Below Image)
	c  - POM class should provide a function which takes input as the Section Name ( e.g. Why Gitlab / Community / Company) and it prints all the name and HREF’s of the respective footer links. (3 marks)
	e.g. “Company“ if it is sent as an argument to function in step above  – it should print for all the footer links (hrefs) and the names like below
	e.g Company
	• About – href is =
	• What is GitLab? – href is = ..
	• Jobs – href is = …
	• Culture – href is = … 
	• Team – href is = …
	• Press – href is = …
	• Analysts – href is =
	• Handbook – href is =
	• Security – href is =
	• Contact – href is =
	• Terms – href is =
	• Privacy – href is =
	• Trademark – href is =
	d – The function should return a hashmap with key name being the footer link text and the value being the href (2 marks)
	e – Create a separate Junit Test, such that the above POM class object is created, the method/function in step c above is called and the key value pair received are asserted by visiting the pages and confirming whether the pages are opening or not for all the footer link received. In other words, the test should iterate through the Hashmap keys and open the href values. (3 marks)
	*/
package cpsatExamJunit;

import java.util.HashMap;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import com.testing.base.TestBase;

public class Set11_Question3 extends TestBase{
	
	//Defining a Hash Map
	HashMap<String, String> hMap1 = new HashMap<String, String>();
	
	//To open browser and navigate to link
	@Before
	public void launchBrowser() {
		init("Chrome","https://gitlab.com/");
	}
	
	//To call the footer sections
	@Test
	public void validateFooterLinks() throws InterruptedException {
	hMap1 = Question3FooterPom.footerLink("Why GitLab?");
	hMap1 = Question3FooterPom.footerLink("Resources");
	hMap1 = Question3FooterPom.footerLink("Community");
	hMap1 = Question3FooterPom.footerLink("Support");
	hMap1 = Question3FooterPom.footerLink("Company");
	}
	
	//To close browser
	@After
	public void closeBrowser() {
		d.close();
	}
}

