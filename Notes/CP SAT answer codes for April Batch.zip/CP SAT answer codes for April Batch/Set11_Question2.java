/*Use TestNG, do the following steps in a data driven test format. Use @Dataprovider or similar way to execute the following steps for the given excel sheet below.(Refer Excel Sheet Snapshot)
    • The first column is whether to execute this test or not
    • Second column is the Main Menu name on the top of the page, image as below(Refer Support Menu Snapshot)
    • Third Column is the sub menu name
	1. Open the website https://gitlab.com/
	2. For every row check if the test is to be executed, if yes take your mouse to the main menu as per the second column of the excel sheet. (3 marks)
	3. The submenu will be visible, take a screen shot such that the screenshot name has the submenuname in the the file name. (3 marks)
	4. Assert that the submenu name for that row is visible or not – (3 marks)
	5. Click on the submenu for that row, such that it opens the sub menu (3 marks)
	6. Print the title of the sub menu page which has been opened – (3 marks)
Please note that NO HARDCODING has to be done either for the submenu url’s or for anything else. The tests should run even if we change the submenu column details.
Marks will be given only if the test is data driven. No marks will be given if the test is not data driven.*/
package cpsatExamJunit;

import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.testing.base.TestBase;

public class Set11_Question2 extends TestBase{

	//To open browser
	@BeforeMethod
	public void launchBrowser()
	{
		init("Chrome","https://gitlab.com/");
	}

	public void menu(String execute, String menuitem, String submenu1) throws InterruptedException{
		checkPageReady();
		List<WebElement> menuitems=d.findElements(By.xpath("//a[text()='"+menuitem+"']"));
		
		//Verifies if the Execute column is yes or no
		if(execute.contains("Yes")) {
		Assert.assertEquals(menuitems.size()>0,true);
		Actions action = new Actions(d);
		
		//To move to header element
		action.moveToElement(d.findElement(By.xpath("//a[text()='"+menuitem+"']"))).build().perform();
		
		//To take screenshot of dropdown
		takeTheScreenShot("Question11_2.jpg");
		List<WebElement> submenuname=d.findElements(By.xpath("//a[text()='"+submenu1+"']"));
		if(submenuname.size()>0){
			String actlink=d.findElement(By.xpath("//a[text()='"+submenu1+"']")).getText();
			
			//To verify if the submenu provided in the excel and page are same
			Assert.assertEquals(actlink,submenu1);
			
			//To click on the submenu link
			d.findElement(By.xpath("//a[text()='"+submenu1+"']")).click();
			
			//To take screenshot of the submenu page
			takeTheScreenShot("Question11_2_1.jpg");
			
			//To print the title of the submenu page
			System.out.println("Title of the page is: "+d.getTitle());
			wait(15);
			
			//To navigate back to home page
			d.navigate().back();
			checkPageReady();
		}
		}
		
		//If execute column is no
		else {
			System.out.println("Execution is No");
		}
	}
	
	//To read data from excel
	@Test
	public void Test1() throws Exception {

		for (int i = 0; i < 17; i++) {
			menu(readData("src\\test\\resources\\TestData\\Set11_Quesion2.xlsx", "Set11_Question2", i, 0),
					readData("src\\test\\resources\\TestData\\Set11_Quesion2.xlsx", "Set11_Question2", i, 1),
					readData("src\\test\\resources\\TestData\\Set11_Quesion2.xlsx", "Set11_Question2", i, 2));
		}
	}
	
	//To close browser
		@AfterMethod
		public void closeBrowser()
		{
			d.close();
		}
	}
