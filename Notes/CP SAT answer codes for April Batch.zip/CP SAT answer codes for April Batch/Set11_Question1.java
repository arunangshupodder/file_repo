	/*	Q1.) 1. Open  http://gtr2017.agiletestingalliance.org/ (no mark) 
	2. Click on the speakers menu on the top (1 mark)
	3. Using FindElements and a relevant locator find out how many speakers (all speakers including panel/keynote/any other) (2 mark)
	4. Print the total number of speakers on the system console (use System.println) (1 mark)
	5. Find out how many speakers have exact word “Coach” in their title (Coaching is not ok). Print the title of all the speakers on system console who have “Coach” in their title. (1 mark)
	6. Find out how many speakers have exact word “Head” in their title. Print the title of all the speakers on system console who have “Head” in their title. (1 mark)
	7. Scroll down to the part of the page which shows “Brought to you by” (Refer Below Image). (1 mark)
	8. Take a screenshot of the page showing brought to you by (1 mark)
	9. Make sure you use driver.quit() to close all the open windows. (no marks)
	10. If all the above steps work without any exceptions and compiler errors you get remaining. (2 marks)*/
package cpsatExamTestNG;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.testing.base.TestBase;

public class Set11_Question1 extends TestBase{

@BeforeMethod
public void launchBrowser() {
	init("Chrome", "http://gtr2017.agiletestingalliance.org/");
}
@Test
public void validateApplication() throws InterruptedException {
	//clicking on Speakers
	checkPageReady();
	d.findElement(By.xpath("//div[@class='container']//child::li[2]/a")).click();
	//getting list of all speakers and their counts
	System.out.println("All the speakers are: ");
	List<WebElement> speakers_list1 = d.findElements(By.xpath("//div[@class='first_speakers unset_height']"));
	List<WebElement> speakers_list = d.findElements(By.xpath("//div[@class='first_speakers unset_height']//child::strong"));
	int size1 = speakers_list.size();
	System.out.println(size1);
	wait(10);
	for(int j=0;j<speakers_list.size();j++) {
		WebElement speaker_list = speakers_list.get(j);
		System.out.println(speaker_list.getText());
	}
	wait(10);
	//printing all the coaches names
	System.out.println("Coaches names are: ");
	for(int k=0;k<speakers_list1.size();k++) {
		WebElement speaker_list = speakers_list1.get(k);
		WebElement speaker_list1 = speakers_list.get(k);
		if(speaker_list.getText().contains("Coach")) {
		System.out.println(speaker_list1.getText());
		}
		else if(speaker_list.getText().contains("coach")) {
		System.out.println(speaker_list1.getText());
		}
	}
	//printing all the head names
	System.out.println("Head names are: ");
	for(int i=0;i<speakers_list.size();i++) {
		WebElement speaker_list2 = speakers_list1.get(i);
		WebElement speaker_list3 = speakers_list.get(i);
		if(speaker_list2.getText().contains("Head")) {
		System.out.println(speaker_list3.getText());
		}
		else if(speaker_list2.getText().contains("head")) {
		System.out.println(speaker_list3.getText());
		}
	}
	
	//scrolling into Brought by section of the page
	scrollIntoView(d.findElement(By.xpath("//div[@class='sponsor_content']//h3")));
	
	//taking screenshot of this section
	takeTheScreenShot("Question11.jpg");
}
@AfterMethod
public void closeBrowser() {
	d.quit();
}
}

