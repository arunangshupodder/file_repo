package cpsatExamTestNG;


import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.testing.base.TestBase;

public class Set13_Question5Page extends TestBase{
	
	public static List<WebElement> Search(String search){
		d.findElement(By.xpath("//div[@id='tablepress-2_filter']/label/input")).sendKeys(search);
		List<WebElement> team = d.findElements(By.xpath("//table[@id='tablepress-2']/tbody/tr"));
		return team;		
	}
	public static List<String> FindTeams(String search) {
		d.findElement(By.xpath("//div[@id='tablepress-2_filter']/label/input")).clear();
		d.findElement(By.xpath("//div[@id='tablepress-2_filter']/label/input")).sendKeys(search); 
		List<WebElement> lists= d.findElements(By.xpath("//table[@id='tablepress-2']/tbody/tr/td[@class='column-2']"));
		List<String> list = new ArrayList<String>();
		for (WebElement e : lists) {
			list.add(e.getText());
		}
		  return list;
		
	}
	
	public static List<String> FindTeamSerialNumber(int value) {
		String value1 = Integer.toString(value);
		d.findElement(By.xpath("//div[@id='tablepress-2_filter']/label/input")).clear();
		d.findElement(By.xpath("//div[@id='tablepress-2_filter']/label/input")).sendKeys(value1); 
		List<WebElement> lists= d.findElements(By.xpath("//table[@id='tablepress-2']/tbody/tr/td[@class='column-2']"));
		List<String> list = new ArrayList<String>();
		for (WebElement e : lists) {
			list.add(e.getText());
		}
		  return list;
	}
	

}
