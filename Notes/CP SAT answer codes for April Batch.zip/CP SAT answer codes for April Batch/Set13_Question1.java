/*Open the website https://doppa2020.devopsppalliance.org/about-us/ 
-	Fetch all team member names under “Team Behind this conference” and print the values in the console
-	Use CommunityUtility class to create function to write all the values printed above in an excel.*/

package cpsatExamJunit;

import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.testing.base.TestBase;

public class Set13_Question1 extends TestBase{
	
	//Opening the browser
	@Before
	public void launchBrowser() {
		init("Chrome", "https://doppa2020.devopsppalliance.org/about-us/ ");
	}
	
	@Test
	public void validateApplication() throws Exception {
		
	//Fetch all team member names under “Team Behind this conference” and print the values in the console
		scrollIntoView(d.findElement(By.xpath("//h3[contains(text(),'Team Behind this conference')]")));
		List<WebElement> teamMembers = d.findElements(By.xpath("//div[@class='elementor-widget-container']/h4"));
		for(int i=0;i<teamMembers.size();i++) {
			WebElement teamMember = teamMembers.get(i);
			System.out.println(teamMember.getText());
			setData("src\\test\\resources\\TestData\\Set13_Question1.xlsx", "Question1", i, 0, teamMember.getText());
		}
	}
	
	//Closing the browser
	@After
	public void closeBrowser() {
		d.close();
	}

}

