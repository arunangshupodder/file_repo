/*Open https://cpdof.devopsppalliance.org/. 
Scroll to the bottom of the page – where you will see Tweets section. Take a screen shot showing the tweets section
Find out how many tweets are visible in the tweets section. Print the number of tweets on the system console
For the first tweet construct the entire message and print on the console – like for the example image shown in step 2 above
Mouse over to the @ handle – it will show the handle as a tool tip. Take a screenshot*/

package cpsatExamTestNG;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.testing.base.TestBase;

public class Set13_Question4 extends TestBase{

	//Opening the browser
	@BeforeMethod
	public void launchBrowser() {
		init("Chrome","https://cpdof.devopsppalliance.org/");
	}
	
	@Test
	public void validateApplication() throws InterruptedException {
		
		checkPageReady();
		
		//Scroll to the bottom of the page – where you will see Tweets section. 
		scrollIntoView(d.findElement(By.xpath("//div[@class='social_container']")));
		d.switchTo().frame("twitter-widget-0");
		
		//Take a screen shot showing the tweets section	
		takeTheScreenShot("Set13_Question7_1.jpg");
		
		//Find out how many tweets are visible in the tweets section
		List<WebElement> tweets = d.findElements(By.xpath("//div[@class='TweetAuthor-nameScreenNameContainer']/span/span"));
		System.out.println(tweets.size());
		
		//Print the number of tweets on the system console
		for(int i=0;i<tweets.size();i++) {
			System.out.println(tweets.get(i).getText());
		}
	
		//For the first tweet construct the entire message and print on the console
		System.out.println(d.findElement(By.xpath("//div[@data-tweet-id='1257590460744433664']/p")).getText());
		
		//Mouse over to the @ handle – it will show the handle as a tool tip. Take a screenshot
		Actions action = new Actions(d);
		waitForElementToVisible(d.findElement(By.xpath("//a[@class='customisable-highlight']")));
		action.moveToElement(d.findElement(By.xpath("//a[@class='customisable-highlight']"))).build().perform();
		wait(5);
		takeTheScreenShot("Set13_Question7_2.jpg");
	}
	
	//Closing the browser
	@AfterMethod
	public void closeBowser() {
		d.close();
	}
}
