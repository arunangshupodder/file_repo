/*Open https://www.ataevents.org/
-	Scroll down till “Upcoming Events”
-	Take Screenshot of the page 
-	Print all the events on the console
-	Scroll on the icons like facebook , twitter etc
-	Take Screenshot
-	Print the URL of the Facebook Icon
-	Go the facebook URL by switching to new window
-	Take Screenshot of the page
-	Assert title with “Agile Testing Alliance – Home”*/

package cpsatExamJunit;

import java.util.List;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

import com.testing.base.TestBase;


public class Set13_Question2 extends TestBase{

	//Opening the browser
	@Before
	public void launchBrowser() {
	init("Chrome", "https://www.ataevents.org/");
	}
	
	@Test
	public void validateApplication() throws InterruptedException {
		
		checkPageReady();

		//Scroll down till “Upcoming Events”
		scrollIntoView(d.findElement(By.xpath("//div[@class='sc_heading   ']/h3")));
		
		//Take Screenshot of the page 
		takeTheScreenShot("Question13_1.jpg");
		wait(5);
		
		//Print all the events on the console
		List<WebElement> events = d.findElements(By.xpath("//div[@class='wpb_wrapper']/h5/a"));
		for(int i=0;i<events.size();i++) {
			System.out.println(events.get(i).getText());
		}
		wait(5);
		
		//Scroll on the icons like facebook, twitter etc
		scrollIntoView(d.findElement(By.xpath("//h3[contains(text(),'Follow us')]")));
		
		//Take Screenshot
		takeTheScreenShot("Question13_1_1.jpg");
		
		//Print the URL of the Facebook Icon
		WebElement social = d.findElement(By.xpath("//div[@class='social_icon']/a"));
		System.out.println(social.getAttribute("href"));
				
		//Go the facebook URL by switching to new window
		social.click();
				
		//Take Screenshot of the page
		takeTheScreenShot("Question13_1_2.jpg");
				
		//Assert title with “Agile Testing Alliance – Home”*/
		for (String winHandle:d.getWindowHandles()) {
			d.switchTo().window(winHandle);
		}
		String pageTitle = d.getTitle();
		System.out.println(pageTitle);
		wait(3);
		Assert.assertEquals("Agile Testing Alliance - Home | Facebook", pageTitle);
	}
	
	//Closing the browser
	@After
	public void closeBrowser() {
		d.quit();
	}
	
}
