/*Use Page Object Model to create different classes .
Navigate to "https://gtr.agiletestingalliance.org/leaderboard/#CTHackATAhon"
Had to create POM Class with 3 functions 
1.Search with keyword in search textbox and store the result table row in list<webelement>. It should be dynamic function such that whatever different number of rows are returned with different search keyword, all those should be stored in the List.
2.Search with keyword in search textbox and store the team name in String array. It should be dynamic function such that whatever different number of team names are returned with different search keyword, all those should be stored in the array.
3.Search with serial number in search textbox and store the result serial number in array. It should be dynamic function such that whatever different number of rows are returned with different search keyword, all those should be stored in the List. Also if I search serial number as 1 then all records having serial number 1 should only be stored not any other record.
Create 3 @test to utilize these functions. If POM function is not consumed by @test then no marks will be given.*/

package cpsatExamTestNG;

import java.util.List;

import org.openqa.selenium.WebElement;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.testing.base.TestBase;

public class Set13_Question5 extends TestBase{

	Set13_Question5Page set1 = new Set13_Question5Page();
	
	//Opening the browser
	@BeforeClass
	public void launchBrowser() {
		init("Chrome","https://gtr.agiletestingalliance.org/leaderboard/#CTHackATAhon");
	}
	
	//Search with keyword in search textbox and store the result table row in list<webelement>
	@Test(priority = 1)
	public void validateTeam() {
		System.out.println("Keyword in search textbox and store in list: ");
		List<WebElement> team = Set13_Question5Page.Search("Winner");
		for(int i=0;i<team.size();i++) {
			System.out.println(team.get(i).getText());
		}
		System.out.println("****************************************");
		wait(5);
	}
	
	//Search with keyword in search textbox and store the team name in String array
	@Test(priority = 2)
	public void validateTeam1() {
		System.out.println("Keyword in search textbox and store in string: ");
		List<String> teams = Set13_Question5Page.FindTeams("Ayas Das");
		for(int j=0;j<teams.size();j++) {
			System.out.println(teams.get(j));
		}
		System.out.println("****************************************");
		wait(5);
	}

	//Search with serial number in search textbox and store the result serial number in array
	@Test(priority = 3)
	public void validateTeam2() {
		System.out.println("Serial number in search textbox and store in string: ");
		List<String> teams1 = Set13_Question5Page.FindTeamSerialNumber(1);
		for(int k=0;k<teams1.size();k++) {
			System.out.println(teams1.get(k));
		}
		System.out.println("****************************************");
		wait(5);
	}
	
	//Closing the browser
	@AfterClass
	public void closeBrowser() {
		d.close();
	}
}
