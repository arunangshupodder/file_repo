/*Navigate to the Page: https://www.ndtv.com/business?pfrom=home-header-globalnav
Print the href of all the top stories (Similar question which we did during our session) on console
Click on the site dropdown and change it to FNO.
Search for text “TCS”
Verify the search results for TCS videos count
Read the Header texts like Cricket, life and Health from Excel and write the href of the respective headers into Excel.
Get the value of Gold for today and click on Nifty from market indicator and click on “By Gain“ tab and get the gain value of ITC.*/

package cpsatExamTestNG;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.testing.base.TestBase;

public class Set12 extends TestBase{
	
	//OpenBrowser
	@BeforeMethod
	public void launchBrowser() {
		init("Chrome", "https://www.ndtv.com/business?pfrom=home-header-globalnav");
	}
	
	@Test
	public void validateApplication() throws Exception {
		checkPageReady();
		
		//Print the href of all the top stories
		System.out.println("Top stories are: ");
		WebElement top = d.findElement(By.xpath("//div[@class='bud_topstory']//child::div[2]/h1/a"));
		System.out.println(top.getAttribute("href"));
		List<WebElement> topStories = d.findElements(By.xpath("//div[@class='bud_otherstories1']//p/a"));
		for(int i=0;i<topStories.size();i++) {
			WebElement topStory = topStories.get(i);
			System.out.println(topStory.getAttribute("href"));
		}
		wait(5);
		
		//Click on the site drop down and change it to FNO
		WebElement iframe1 = d.findElement(By.xpath("//iframe[@src='https://www.ndtv.com/business/marketdata/market-embedded2?iframe=1']"));
		d.switchTo().frame(iframe1);
		d.findElement(By.xpath("//select[@id='type']/option[@value='FNOStock']")).click();		
		wait(5);
		
		//Search for text “TCS”
		WebElement search = d.findElement(By.xpath("//input[@id='search']"));
		search.sendKeys("TCS");
		search.sendKeys(Keys.ENTER);
		
		//Verify the search results for TCS videos count
		d.findElement(By.xpath("//ul[@class='trendstabs']//child::li[3]/a")).click();
		checkPageReady();
		wait(5);
		String videocount = d.findElement(By.xpath("//div[@id='videoresults']/child::div[2]/div/span")).getText();
		System.out.println(videocount);
		if(videocount.contains("'TCS' - 325 Video Result(s)")) {
			System.out.println("Video count verified");
		}
		else {
			System.out.println("Wrong count");
		}
		
		//Read the Header texts like Cricket, life and Health from Excel and write the href of the respective headers into Excel.
		d.navigate().back();
		checkPageReady();
		List<WebElement> headers = d.findElements(By.xpath("//div[@class='nglobalnav']/a"));
		for(int j=0;j<headers.size();j++) {
			System.out.println(headers.get(j).getText());
			setData("src\\test\\resources\\TestData\\Set11_Quesion2.xlsx","Set12_Question1",j,0,headers.get(j).getAttribute("href"));
		}
			
		//Get the value of Gold for today 
		wait(5);
		d.switchTo().frame(d.findElement(By.xpath("//iframe[@src='https://www.ndtv.com/business/marketdata/market-embedded2?iframe=1']")));
		wait(5);
		waitForElementToVisible(d.findElement(By.xpath("//div[@id='header-data']/a/h5[contains(text(),'GOLD')]")));
		System.out.println(d.findElement(By.xpath("//a[@href='https://www.ndtv.com/business/commodity/gold-price_gold_05-06-2020']/span/span[2]")).getText());
		wait(5);
		
		//Click on Nifty from market indicator 
		waitForElementToClickable(d.findElement(By.xpath("//div[@id='header-data']/a/h5[contains(text(),'NIFTY')]")));
		wait(5);
		d.findElement(By.xpath("//div[@id='header-data']/a[@href='https://www.ndtv.com/business/marketdata/domestic-index-nse_nifty']/span/span[2]")).click();
		wait(5);
		
		//Click on “By Gain“ tab and get the gain value of ITC.
		d.findElement(By.xpath("//div[@class='subtabs-header']/ul/child::li[2]/a")).click();
		wait(5);
		String gainValue = d.findElement(By.xpath("//div[@class='sub-output']/ul/child::li/a[contains(text(),'ITC')]")).getText();
		System.out.println(gainValue);
}

	//Close Browser
	 @AfterMethod 
	 public void closeBrowser() {
		 d.close(); 
	 }
}
