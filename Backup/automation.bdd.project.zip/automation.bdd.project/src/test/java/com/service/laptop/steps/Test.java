package com.service.laptop.steps;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class Test {
    @Given("^I want to write an? step with precondition with \"(.*)\"$")
    public void givenStep(String str) {
        System.out.println("in given: " + str);
    }

    @Given("^User is navigated to login page$")
    public void givenStep() {
        System.out.println("in given");
    }
    
    @When("^User logs in with username \"(.*)\" and password \"(.*)\"$")
    public void whenStep1(String username, String password) {
        System.out.println("in when 1");
        System.out.println("username: " + username);
        System.out.println("password: " + password);
    }
    
    @When("^User logs in with invalid credentials \"(.*)\" and (\\d*)$")
    public void whenStep2(String username, int password) {
        System.out.println("in when 2");
        System.out.println("username: " + username);
        System.out.println("password: " + (password+8768));
    }
    
    @Then("^User is able to log in and navigate to home page$")
    public void thenStep() {
        System.out.println("in then");
    }
    
    @When("Testing cucumber expressions with data {int} and {string}")
    public void cukesStep(Integer var, String word) {
        System.out.println("Data found: " + var);
        System.out.println("Data found: " + word);
    }
}
