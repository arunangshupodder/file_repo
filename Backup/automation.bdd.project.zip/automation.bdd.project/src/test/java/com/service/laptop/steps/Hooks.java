package com.service.laptop.steps;

import java.io.IOException;
import java.net.MalformedURLException;

import com.framework.base.BaseTest;
import com.framework.utils.Services;

import io.cucumber.java.After;
import io.cucumber.java.Before;

public class Hooks {
    private BaseTest baseTest;

    public Hooks(BaseTest baseTest) {
        this.baseTest = baseTest;
    }

    @Before
    public void testSetup() throws MalformedURLException, IOException {
        baseTest.setup();
        baseTest.service = new Services(baseTest.getBaseApiURL());
    }

    @After
    public void testTeardown() {
        baseTest.teardown();
    }
}
