package com.service.laptop.steps;

import com.framework.base.BaseService;
import com.framework.utils.StepData;

import io.cucumber.java.en.When;

public class LaptopServices {

    private BaseService base;
    private StepData stepData;

    //for dependency injection
    public LaptopServices(BaseService base, StepData stepData) {
        this.base = base;
        this.stepData = stepData;
    }

    @When("^User enters the details$")
    public void createNewLaptop() {
        stepData.response = base.service.post(base.LAPTOP_ADD_URL, stepData.laptopDetails);
    }
}
