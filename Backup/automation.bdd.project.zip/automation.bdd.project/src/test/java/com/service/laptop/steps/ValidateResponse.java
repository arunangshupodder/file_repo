package com.service.laptop.steps;

import com.framework.base.BaseService;
import com.framework.utils.AssertionBuilder;
import com.framework.utils.StepData;

import io.cucumber.java.en.Then;
import io.restassured.response.Response;

import static org.junit.Assert.*;

import java.util.List;

public class ValidateResponse {

    private BaseService base;
    private StepData stepData;

    public ValidateResponse(BaseService base, StepData stepData) {
        this.base = base;
        this.stepData = stepData;
    }

    @Then("New laptop details are created with response status as {int}")
    public void validateRepsonseStatusCode(int expectedStatus) {
        int actualStatusCode = base.getStatusCode(stepData.response);
        assertTrue("Response status code does not match. Expected: " + expectedStatus + ". But actual: " + actualStatusCode, actualStatusCode==expectedStatus);
    }

    @Then("The response contains id of newly created laptop")
    public void validateLaptopIdInResponse() {
        int expectedId = stepData.laptopDetails.getId();
        int actualResponse = base.getIntFromResponse(stepData.response, "Id");
        assertTrue("Laptop Id in response does not match. Expected: " + expectedId + ". But actual: " + actualResponse, expectedId==actualResponse);
    }

    @Then("The response contains accurate details of the laptop")
    public void validateLaptopDetailsInResponse() {
        String expectedBrandName = stepData.laptopDetails.getBrandName();
        String expectedLaptopName = stepData.laptopDetails.getLaptopName();
        List<String> expectedFeatures = stepData.laptopDetails.getFeatures().getFeatures();
        
        String actualBrandName = base.getStringFromResponse(stepData.response, "BrandName");
        String actualLaptopName = base.getStringFromResponse(stepData.response, "LaptopName");
        List<Object> actualFeatures = base.getListFromResponse(stepData.response, "Features.Feature");
        System.out.println("actual list: " + actualFeatures);
        System.out.println("expected list: " + expectedFeatures);
        
        String validationMessage = base.validateResponseContentContainsListItems(expectedFeatures, actualFeatures);
        
        AssertionBuilder builder = AssertionBuilder.newBuilder();
        builder.and(actualBrandName.trim().equals(expectedBrandName), "Brand Name in the response do not match. Expected: " + expectedBrandName + " Actual: " + actualBrandName)
               .and(actualLaptopName.trim().equals(expectedLaptopName), "Laptop Name in the response do not match. Expected: " + expectedLaptopName + " Actual: " + actualLaptopName)
               .and(validationMessage.isEmpty(), "Features present in the response do not match expected features list. " + validationMessage);
        assertTrue(builder.getMessage(), builder.result());
    }
}
