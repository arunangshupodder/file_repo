
package com.service.laptop.steps;

import java.util.ArrayList;
import java.util.List;

import com.framework.base.BaseService;
import com.framework.objects.Features;
import com.framework.objects.LaptopDetails;
import com.framework.utils.Config;
import com.framework.utils.StepData;

import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.Given;

public class SetLaptopDetails {
    private BaseService base;
    private StepData stepData;
    
    //for dependency injection
    public SetLaptopDetails(BaseService base, StepData stepData) {
        this.base = base;
        this.stepData = stepData;
    }

    @Given("User has valid laptop details with {word} laptop id")
    public void setLaptopDetailsWithNewId(String type, DataTable table) {
        List<List<String>> data = table.asLists();
        
        Features features = new Features();
        ArrayList<String> featuresList = new ArrayList<String>();
        featuresList.add(data.get(1).get(2));
        featuresList.add(data.get(1).get(3));
        features.setFeatures(featuresList);
        
        stepData.laptopDetails = new LaptopDetails();
        stepData.laptopDetails.setBrandName(data.get(0).get(0));
        stepData.laptopDetails.setLaptopName(data.get(0).get(1));
        if (type.equalsIgnoreCase("new")) {
            stepData.laptopDetails.setId(base.createLaptopId());
        } else {
            stepData.laptopDetails.setId(Config.getLaptopId("default"));
        }
        stepData.laptopDetails.setFeatures(features);
    }

    @Given("^User has valid laptop details as (.*), (.*), (.*) and (.*) with new laptop id$")
    public void setLaptopDetailsWithNewId(String brandName, String laptopName, String feature1, String feature2) {
        Features features = new Features();
        ArrayList<String> featuresList = new ArrayList<String>();
        featuresList.add(feature1);
        featuresList.add(feature2);
        features.setFeatures(featuresList);
        
        stepData.laptopDetails = new LaptopDetails();
        stepData.laptopDetails.setBrandName(brandName);
        stepData.laptopDetails.setLaptopName(laptopName);
        stepData.laptopDetails.setId(base.createLaptopId());
        stepData.laptopDetails.setFeatures(features);
    }
}
