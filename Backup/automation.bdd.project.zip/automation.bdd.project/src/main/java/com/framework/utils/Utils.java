package com.framework.utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import org.apache.poi.EncryptedDocumentException;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellType;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.apache.poi.ss.usermodel.Row.MissingCellPolicy;

public class Utils {

    public static int DATA_ROW = 1;
    public static int DATA_ROW_COUNT = 0;
    private static Workbook workbook = null;
    private static Sheet sheet = null;
    private static Properties properties = null;

    public Utils() throws IOException {
        FileReader reader=new FileReader("src/test/resources/test.properties");
        properties = new Properties();
        properties.load(reader);
    }

    /*
     * Method to read data from .properties file
     */
    public static String getProperty(String key) {
        return properties.getProperty(key);
    }

    /*
     * Method to read data from excel using data provider
     */
    public static void initDataPool(String fileName, String sheetName) throws EncryptedDocumentException, IOException {
        File file = new File(fileName);
        FileInputStream inputStream = new FileInputStream(file);
        workbook = WorkbookFactory.create(inputStream);
        sheet = workbook.getSheet(sheetName);
    }

    public static void clearDataPool() throws IOException {
        if (workbook != null) {
            workbook.close();
        }
    }

    public static Map<String, Object> getData() throws IOException {
        Map<String, Object> dataMap = new HashMap<String, Object>();
        Row row = sheet.getRow(DATA_ROW);
        if (!(getCell(row, 1).toString().equalsIgnoreCase("N") || getCell(row, 1).toString().equalsIgnoreCase("No"))) {
            for (int j = 0; j < row.getLastCellNum(); j++) {
                if (getCell(row, j).getCellType() == CellType.STRING) {
                    dataMap.put(getCell(sheet.getRow(0), j).getStringCellValue(), getCell(row, j).getStringCellValue());
                } else if (getCell(row, j).getCellType() == CellType.NUMERIC) {
                    dataMap.put(getCell(sheet.getRow(0), j).getStringCellValue(), Double.toString(getCell(row, j).getNumericCellValue()));
                }
            }
        }
        DATA_ROW++;
        return dataMap;
    }

    public static int getDataCount() throws EncryptedDocumentException, IOException {
        return sheet.getLastRowNum();
    }

    private static Cell getCell(Row row, int index) {
        return row.getCell(index, MissingCellPolicy.CREATE_NULL_AS_BLANK);
    }
}
