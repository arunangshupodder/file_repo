package com.framework.utils;

import com.framework.objects.LaptopDetails;

import io.restassured.response.Response;

public class StepData {
    public LaptopDetails laptopDetails;
    public Response response;
}
