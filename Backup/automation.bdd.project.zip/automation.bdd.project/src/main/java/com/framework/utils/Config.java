package com.framework.utils;

import static com.framework.utils.Utils.*;

public class Config {

    public static String getLocalGridURL() {
        return getProperty("grid.hub.local");
    }

    public static String getBaseURL() {
        return getProperty("base.url");
    }

    public static String getBaseApiUrl() {
        return getProperty("base.api.url");
    }

    public static Integer getLaptopId(String laptopIdType) {
        return Integer.parseInt(getProperty("laptop."+laptopIdType+".id"));
    }
}
