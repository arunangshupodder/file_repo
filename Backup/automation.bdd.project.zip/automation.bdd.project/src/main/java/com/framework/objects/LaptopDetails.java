package com.framework.objects;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

@JsonInclude(Include.NON_NULL)
public class LaptopDetails {
    @JsonProperty("BrandName")
    private String brandName = "";
    @JsonProperty("Features")
    private Features features = null;
    @JsonProperty("Id")
    private int id = 0;
    @JsonProperty("LaptopName")
    private String laptopName = "";

    public String getBrandName() {
        return brandName;
    }
    public void setBrandName(String brandName) {
        this.brandName = brandName;
    }
    public Features getFeatures() {
        return features;
    }
    public void setFeatures(Features features) {
        this.features = features;
    }
    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }
    public String getLaptopName() {
        return laptopName;
    }
    public void setLaptopName(String laptopName) {
        this.laptopName = laptopName;
    }
}
