package com.framework.utils;

public class AssertionBuilder {
    private boolean result = true;
    private String text="";

    public static AssertionBuilder newBuilder() {
        return new AssertionBuilder();
    }

    /**
    * This class is created to perform multiple assertions together.
    * Also the assertion continues even if some of assert fails and logs all the failure at the end.
    */
    
    public AssertionBuilder and(boolean condition, final String msg) {
        StringBuilder logBuilder = new StringBuilder();
        result = result && condition;
        if (!condition) {
            logBuilder.append(text).append(msg).append(System.lineSeparator());
            text=logBuilder.toString();
        }
        return this;
    }
    
    public boolean result() {
        return result;
    }
    
    public String getMessage() {
        return text;
    }
   
}
