package com.framework.utils;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.http.Headers;
import io.restassured.response.Response;

public class Services {

    public Services() {
        // this is to initialize object without any parameters
    }

    public Services(String url) {
        setBaseURL(url);
    }

    public void setBaseURL(String url) {
        RestAssured.baseURI = url;
    }

    public Response get(String path) {
        Response reponse = RestAssured.given().accept(ContentType.JSON).when().get(path);
        return reponse;
    }

    public Response get(String path, Headers headers) {
        Response response = RestAssured.given().headers(headers).when().get(path);
        return response;
    }
    
    public Response get(String path, String queryKey, String queryValue) {
        Response response = RestAssured.given().accept(ContentType.JSON).queryParam(queryKey, queryValue).when().get(path);
        return response;
    }

    public Response post(String path) {
        Response response = RestAssured.given().accept(ContentType.JSON).when().post(path);
        return response;
    }

    public Response post(String path, Object body) {
        Response response = RestAssured.given().log().all().accept(ContentType.JSON).with().contentType(ContentType.JSON).and().body(body)
                                       .when().post(path);
        response.prettyPrint();
        return response;
    }
}
