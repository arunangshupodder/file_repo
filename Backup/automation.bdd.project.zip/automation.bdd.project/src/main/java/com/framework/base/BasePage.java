package com.framework.base;

public class BasePage extends BaseTest {
    
}
