package com.framework.base;

import java.io.IOException;
import java.net.MalformedURLException;
import java.util.Random;
import java.util.concurrent.TimeUnit;

import com.framework.utils.Config;
import com.framework.utils.Services;
import com.framework.utils.Utils;

public class BaseTest {

    private static String baseApiUrl;
    private static Utils utils = null;
    public  static Services service = null;
    public final String LAPTOP_ADD_URL = "/add";

    public void setup() throws MalformedURLException, IOException {
        utils = new Utils();
        setBaseApiURL();
    }

    public void teardown() {
    }

    public static void setBaseURL() {
    }

    public static void setBaseApiURL() {
        baseApiUrl = Config.getBaseApiUrl();
    }

    public static String getBaseApiURL() {
        return baseApiUrl;
    }

    public void wait(int secs) {
        try {
            TimeUnit.SECONDS.sleep(secs);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public int createLaptopId() {
        Random random = new Random();
        return random.nextInt(10000);
    }
}
