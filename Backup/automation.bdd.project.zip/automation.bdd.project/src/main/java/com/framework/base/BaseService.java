package com.framework.base;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.hamcrest.Matchers;
import org.json.JSONObject;

import static org.junit.Assert.*;

import io.restassured.response.Response;

public class BaseService extends BaseTest {
    private static final int STATUS_CODE_200 = 200;

    public void validateSuccessfulResponse(Response response) {
        response.then().assertThat().statusCode(STATUS_CODE_200);
    }
    
    public int getStatusCode(Response response) {
        return response.thenReturn().statusCode();
    }

    public List<Object> getListFromResponse(Response response, String path) {
        return response.jsonPath().getList(path);
    }

    public String getStringFromResponse(Response response, String path) {
        return response.jsonPath().getString(path);
    }

    public String getStringFromResponse(JSONObject response, String path) {
        return response.getString(path);
    }

    public Integer getIntFromResponse(Response response, String path) {
        return response.jsonPath().getInt(path);
    }

    public Integer getIntFromResponse(JSONObject response, String path) {
        return response.getInt(path);
    }

    public void validateResponseContentEqualsIgnoringCase(Response response, String path, String expectedContent) {
        response.then().assertThat().body(path, Matchers.equalToIgnoringCase(expectedContent));
    }

    public void validateResponseContentEqualsIgnoringCase(JSONObject response, String path, String expectedContent) {
        String content = response.getString(path);
        assertTrue("Response content does not match. Expected: " + expectedContent + " Actual: " + content, content.equalsIgnoreCase(expectedContent));
    }

    public void validateResponseContentEquals(Response response, String path, String expectedContent) {
        response.then().assertThat().body(path, Matchers.equalTo(expectedContent));
    }

    public void validateResponseContentEquals(JSONObject response, String path, String expectedContent) {
        String content = response.getString(path);
        assertTrue("Response content does not match. Expected: " + expectedContent + " Actual: " + content, content.equals(expectedContent));
    }

    public void validateResponseContentContainsIgnoringCase(Response response, String path, String expectedContent) {
        response.then().assertThat().body(path, Matchers.containsStringIgnoringCase(expectedContent));
    }

    public void validateResponseContentContainsIgnoringCase(JSONObject response, String path, String expectedContent) {
        String content = response.getString(path);
        assertTrue("Response content does not match. Expected: " + expectedContent + " Actual: " + content, StringUtils.containsIgnoreCase(expectedContent, content));
    }

    public void validateResponseContentContains(Response response, String path, String expectedContent) {
        response.then().assertThat().body(path, Matchers.containsString(expectedContent));
    }

    public void validateResponseContentContains(JSONObject response, String path, String expectedContent) {
        String content = response.getString(path);
        assertTrue("Response content does not match. Expected: " + expectedContent + " Actual: " + content, content.contains(expectedContent));
    }

    public void validateResponseContentContainsListItem(Response response, String path, String expectedContent) {
        response.then().assertThat().body(path, Matchers.hasItem(expectedContent));
    }

    public String validateResponseContentContainsListItems(List<String> expectedItemsList, List<Object> actualItemsList) {
        String msg = "";
        for (String expectedItem : expectedItemsList) {
            if (!(actualItemsList.contains(expectedItem))) {
                msg = msg + "Item " + expectedItem + " is not present in the response.\n";
            }
        }
        return msg;
    }
}
