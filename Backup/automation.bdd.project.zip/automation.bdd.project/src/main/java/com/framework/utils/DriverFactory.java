package com.framework.utils;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

public class DriverFactory {

    private static DriverFactory instance = new DriverFactory();
    public static final Boolean BROWSER_MODE = Boolean.valueOf(System.getProperty("run.in.browser"));
    public static final String BROWSER = System.getProperty("browser.name");
    /*
     * create a thread-safe driver object
     */
    private ThreadLocal<RemoteWebDriver> driver = new ThreadLocal<RemoteWebDriver>() {
        @Override
        protected RemoteWebDriver initialValue() {
            DesiredCapabilities capabilities = DesiredCapabilities.chrome();
            ChromeOptions options=new ChromeOptions();
            options.addArguments("--disable-logging");
            options.addArguments("--disable-notifications");
            capabilities.setCapability(ChromeOptions.CAPABILITY, options);
            RemoteWebDriver webDriver = null;
            if (BROWSER_MODE && BROWSER.equals("chrome")) {
                webDriver = new ChromeDriver(options);
            } else if (BROWSER_MODE && BROWSER.equals("firefox")) {
                //code for firefox driver
            } else {
                capabilities.setBrowserName(BROWSER);
                try {
                    webDriver = new RemoteWebDriver(new URL(Config.getLocalGridURL()), capabilities);
                } catch (MalformedURLException e) {
                    return null;
                }
            }
            webDriver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
            webDriver.manage().timeouts().pageLoadTimeout(30, TimeUnit.SECONDS);
            return webDriver;
        }
    };

    private DriverFactory() {
        //Do-nothing. Do not allow to initialize this class from outside
    }

    public static DriverFactory getInstance() {
        return instance;
    }

    /* 
     * call this method to get the driver object
     */
    public RemoteWebDriver getDriver() {
        return driver.get();
    }

    /* 
     * call this method to kill the driver object
     */
    public void removeDriver() {
        driver.get().quit();
        driver.remove();
    }
}
